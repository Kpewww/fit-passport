# Fit Passport browser extension

Check your size on the product page you're looking at. The extension reads the
page **in your own browser**, sends Fit Passport only the product parts of it, and
shows the size the Fit Passport engine recommends, with its reasons and where
every number came from.

It exists because many retailers refuse server-side requests: their bot
protection detects headless automation, and the configuration that gets past it
needs a real browser window, which a serverless function does not have (see
`docs/design/brand-size-charts.md` §2–2b, invariant (53)). Your browser, looking
at a page you opened, is not what they refuse.

**The extension decides nothing.** Parsing, the body-versus-garment reading, every
refusal and the recommendation itself all happen on the server, in the same code
as the website (`app-web/src/lib/extractorLLM.ts`, `pageParse.ts`, `fitEngine.ts`).
There is one engine, and it is the one with the tests.

## How it works

1. You click the toolbar icon. Chrome's `activeTab` gives the extension access to
   **this tab, now**, and nothing else.
2. `capture.js` builds a small document from the page's product parts (below).
3. The popup shows what it found and how much would be sent. **Nothing leaves
   your browser yet.** "Show exactly what would be sent" displays the payload.
4. You press **Check my size**. The popup sends the payload to `/api/check`
   with your Fit Passport session.
5. The popup shows the size, the confidence, the reasons and the source line, or
   the server's refusal in plain words. **Open full explanation** opens the check
   on the website (`/check?product=<id>`).

If the page's size chart only appears after you open a "Size guide", open it and
press **Re-scan**. The extension never clicks anything on the page for you.

**Save to buy** (0.4.0). From the preview or a result, **Save to buy** opens a short
form — name, brand, the size you mean to buy (the page's sizes, with the one you
picked on the page pre-selected), a note — and saves it to your to-buy list on the
website (`/saved`, `POST /api/saved`). After a check, the stored check is referenced
by id; otherwise the same reduced document the preview shows is sent, and the server
reads name, brand and offered sizes from it without calling a model. Saving the same
product twice (tracking parameters ignored) says so and offers to change the saved
size. A saved product is **not** in your closet and never feeds a recommendation;
"Bought it — add to closet" on the website moves it there once you say how it fits.
No new permission: it uses the same session and host permission as a check.

## Background worker (0.7.2)

`background.js` does one thing: on **first install** it opens `/extension/welcome` (through the session
hand-over since 0.9.0, below) on the first server in `config.js` (production in the store build). It needs no
permission — `chrome.tabs.create` works without `tabs` — and updates open nothing.

## The new address (0.9.0)

The site moved to **https://www.fitpassport.fit** on 2026-10-06 (Session 92), and
0.9.0 talks to it: the host permission and the default server are the new address.
The old one, `fit-passport.vercel.app`, still answers the API for 0.8.0 and earlier.

An unclaimed account is a cookie, and a cookie belongs to one address, so every page
the popup opens (and the welcome page) goes through `/api/session/carry` on the new
address. The first time, it fetches the account this browser had at the old address
with a one-minute pass only this browser can use; after that it is one redirect. The
flow and its safety are in `app-web/src/lib/sessionCarry.ts`.

The new host permission means Chrome asks people who update from the store to
approve it before 0.9.0 runs.

## 0.9.1

Size buttons on screen are read first; hidden ones only when none are on screen (a
picker still closed in a drawer). Patagonia's product page also carries its review
filters, hidden, with every size the brand sells, and all 49 had reached the save form
and the check (Session 95, a live run). No permission change.

## 0.9.2

A size chart that is only on screen — a Google Drive preview, a PDF, a chart drawn by
script — can be read from a screenshot of the tab: shown first, sent only on a click,
with the page's address as its reference and nothing else from the page (Session 100).
Choosing the garment type after a picked picture now sends the picture again (it was
dropped, and the retry answered "no chart"). No permission change: `activeTab` already
allows the screenshot, as it does for closet photos.

## Install (development)

1. `chrome://extensions` → enable **Developer mode**.
2. **Load unpacked** → choose this `browser-extension/` folder.
3. Open Fit Passport once in the same browser (that creates your session), then
   open a product page and click the icon.

The manifest pins a public `key`, so the extension ID is the same everywhere:
**`odbdhmcfjbhikmlfmgafbkkbknkkaecp`**. No private key exists or is needed for
unpacked use. A Chrome Web Store listing would get the store's key instead.

For local development, pick **localhost:3000** under *Server* in the popup and run
`npm run dev` in `app-web/`.

## The Chrome Web Store package (0.6.0)

`node scripts/pack-extension.mjs --store` (in `app-web/`) writes the upload to
`app-web/store-build/`. It is this folder with three things left out, and nothing
else changed (`extensionZip.test.ts` compares every other file):
- the manifest's `key` — the store refuses an upload that has one and assigns its
  own ID (the server never checks the ID, so nothing else changes);
- the `localhost:3000` host permission and server — with one server the popup
  hides its *Server* switch;
- `captureTool` — "Save this capture" is our evaluation tool, not a shopper's.

What to paste into the store's dashboard, and the images: `docs/store/`.

## Permissions, and why each one

| Permission | Why |
|---|---|
| `activeTab` | Read the tab you clicked on, once, when you click. No access to any other page, ever. |
| `scripting` | Inject `capture.js` into that tab on the click. There are **no** always-on content scripts. |
| host permission for Fit Passport's own origin | Lets the popup call the API. Chrome treats an extension's request to a site it holds host permission for as same-site, so your Fit Passport session cookie goes with it. |
| *optional* `https://*.ebaydesc.com/*` (0.5.0) | eBay shows a seller's description in a frame from `itm.ebaydesc.com`, which `activeTab` does not reach. Asked for only when you press **Read the seller's description** on an eBay listing, and used only to read measurement lines from that frame (below). Never requested otherwise; revoke it any time in `chrome://extensions`. |

**Not requested:** access to retailer sites (the eBay description host above is optional and asked for on a click), `<all_urls>`, `tabs`, `cookies`,
`storage`, `webRequest`. If third-party cookies are blocked in your browser, the
cookie is not sent and the server answers "connect Fit Passport first". It never
quietly creates a new, empty account.

## What is sent, and what never is

**Allowlist, not denylist.** A page you are logged into shows who you are in more
places than anyone can list, so the capture never tries to strip the private
parts out of a page. It builds a new document from the few parts known to be
product:

- `<title>` and a few product meta tags (og:title, og:description, site name,
  product:brand, description)
- schema.org Product / ProductGroup / BreadcrumbList JSON-LD, cut down to a short
  list of keys. Reviews (other people's names) and offers are dropped.
- the first `<h1>`
- every table that mentions a measurement, rebuilt as plain-text cells, plus up
  to 1,500 characters from the size-guide dialog or a small section around it
- the one sentence that says whether the chart is body or garment measurements,
  taken from its own element
- the size `<select>`'s options, and short `data-size`/`data-value` swatch values
- `<img>` tags that look like size-chart images: their address and alt text only
- on a one-off listing (0.5.0): item specifics whose label is on a short allowlist (Size, Chest Size, Pit to Pit, Length, Waist, Inseam, Brand …), and — only with the optional permission — lines from the seller's description that name a measurement and hold a number (at most twenty, each at most 200 characters, masked). Free text on the listing page itself is never read: it also lists other sellers' items with their own measurements.

**Never sent:** forms and their values, cart, account, header, navigation, footer,
reviews, recommendations, iframes, scripts (other than the JSON-LD above), styles,
cookies, storage. Query parameters other than product/variant identifiers are
dropped from the address, and so is the `#fragment`. Emails, phone numbers and
card-like numbers that appear in kept text are masked before sending.

On a real Patagonia product page with the size guide open, that is **11 KB out of
a 1.78 MB page (99.4% smaller)**, captured in about 16 ms.

**On the server:** the page itself is never stored. Only what was read from it is
kept: brand, name, category, the size rows, and where each came from. A test pins
that the page's prose does not survive into the stored record.

## Tests and tools

- `app-web/src/lib/extensionCapture.test.ts` loads `capture.js` into jsdom and
  checks three things:
  - **Round trip:** the server's parser reads the capture exactly as it reads the
    full page.
  - **Privacy:** a logged-in page's greeting, cart, address, form values, reviews
    and scripts never appear in the capture.
  - **Drift:** the constants `capture.js` shares with `pageParse.ts` still match.
  Runs with `npm test`.
- `scripts/try-pages.mjs` runs the whole pipeline on real product pages in a fresh
  logged-out Chromium profile and records the numbers. It is for measurement only:
  a headed browser reading a handful of pages once, which is the curation use
  invariant (52) allows. It never runs on anyone's behalf.
- `scripts/make-icons.mjs` renders `icons/` from the brand masters in `brand/`.

Both scripts need Playwright, which is deliberately not a project dependency
(same arrangement as `app-web/scripts/capture-chart.mjs`).

## Known limits

- A size chart inside a **cross-origin iframe** or a **closed shadow root** cannot
  be read. Open shadow roots can be.
- Charts that load only when opened need you to open them first, then **Re-scan**.
- On Taobao/Tmall, a sign-in page or the **访问异常提示** notice can stand in for
  the product. The popup says so (0.5.1) instead of checking: sign in, or wait until
  the page shows its details again, then **Re-scan**.
- When the size guide is a separate page (Nike), the product page holds no chart.
  The server then falls back to the brand's curated chart where one exists, and
  says so.
- Size options offered as radio buttons rather than a `<select>` or swatch
  attributes are not read yet, by the extension or by the server's parser.
- The popup closes if you click elsewhere while it waits for the answer.
